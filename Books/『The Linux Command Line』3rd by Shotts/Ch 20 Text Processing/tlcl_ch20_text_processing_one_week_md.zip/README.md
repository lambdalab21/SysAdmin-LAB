# TLCL Chapter 20 One-Week Text Processing Plan

Use these seven files across one week.

| Day | File | Focus |
|---|---|---|
| Monday | `01_unit1_view_sort_count.md` | cat, wc, sort, uniq |
| Tuesday | `02_unit2_extract_columns_combine.md` | cut, paste, join |
| Wednesday | `03_unit3_transform_text_tr_sed.md` | tr, sed |
| Thursday | `04_unit4_format_output.md` | nl, fold, fmt, pr, printf |
| Friday | `05_unit5_applied_pipelines.md` | applied pipelines |
| Saturday | `06_apply_to_previous_chapters.md` | applying text tools to earlier chapters |
| Sunday | `07_apply_logs_processes_network.md` | logs, processes, networking output |

Main rule: build pipelines one stage at a time and inspect intermediate output.
