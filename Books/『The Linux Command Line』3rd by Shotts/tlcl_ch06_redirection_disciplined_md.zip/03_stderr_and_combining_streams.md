# The Linux Command Line, Chapter 6: Redirection

Use these guides after reading or while reading Chapter 6 of William Shotts, *The Linux Command Line*.

A cleaner phrasing: “Create Markdown file(s) for Shotts Chapter 6, ‘Redirection.’ Use the Feynman method and force disciplined thinking rather than mindless typing.”

Main idea:

```text
A shell command is not just text on a screen.
It has streams.
Redirection changes where those streams go.
```

Core disciplined-thinking rule:

```text
Before pressing Enter, identify:
1. What command will run?
2. What is stdin?
3. Where will stdout go?
4. Where will stderr go?
5. Will a file be created, overwritten, or appended?
6. How will I verify the result?
```

One-time setup:

```bash
mkdir -p ~/tlcl-ch06-redirection/{input,output,errors,lab,tmp}
cd ~/tlcl-ch06-redirection

cat > input/fruits.txt <<'EOF'
apple
banana
orange
banana
apple
grape
EOF

cat > input/names.txt <<'EOF'
alice
bob
charlie
diana
EOF

cat > input/app.log <<'EOF'
INFO started
ERROR failed login alice
INFO request /index.html
WARN disk almost full
ERROR timeout db01
INFO stopped
EOF
```

Verify setup:

```bash
find ~/tlcl-ch06-redirection -maxdepth 2 -type f -print
```

---
# Session 3: stderr, Combining Streams, and `/dev/null`

## Read these Chapter 6 sections

Read the sections covering:

```text
2>
2>>
&>
2>&1
/dev/null
```

The important concept is not the punctuation. The important concept is stream control.

---

## Feynman analogy

A command has two output pipes:

```text
stdout = normal results
stderr = complaints and errors
```

If you only redirect stdout, errors still appear on the screen.

If you redirect stderr, normal output still appears on the screen.

This separation is useful for troubleshooting.

---

# Part A: Redirect stderr only

## Before running

Predict:

```text
Which stream will contain the error?
Will normal output appear on screen?
Will the error appear on screen?
```

Run:

```bash
cd ~/tlcl-ch06-redirection
ls input missing-directory 2> errors/ls-errors.txt
```

Inspect:

```bash
cat errors/ls-errors.txt
```

Question:

```text
What appeared on the terminal, and what went into the file?
```

Expected idea:

```text
The valid input listing appeared on stdout.
The missing-directory error went to errors/ls-errors.txt.
```

---

# Part B: Redirect stdout and stderr to separate files

Run:

```bash
ls input missing-directory > output/ls-output.txt 2> errors/ls-errors-separated.txt
```

Inspect:

```bash
cat output/ls-output.txt
cat errors/ls-errors-separated.txt
```

Explain:

```text
stdout and stderr were captured separately.
This is useful when normal output and errors need different handling.
```

---

# Part C: Append stderr

Run:

```bash
ls missing-one 2>> errors/error-log.txt
ls missing-two 2>> errors/error-log.txt
cat errors/error-log.txt
```

Explain:

```text
2>> appends stderr instead of replacing the file.
```

---

# Part D: Send both stdout and stderr to one file

Run:

```bash
ls input missing-directory > output/combined.txt 2>&1
cat output/combined.txt
```

Explain slowly:

```text
> output/combined.txt sends stdout to the file.
2>&1 sends stderr to the same place stdout is currently going.
```

---

# Part E: Redirection order matters

Run:

```bash
ls input missing-directory > output/order-good.txt 2>&1
cat output/order-good.txt
```

Now run:

```bash
ls input missing-directory 2>&1 > output/order-surprise.txt
cat output/order-surprise.txt
```

Question:

```text
Why did the second command behave differently?
```

Expected idea:

```text
2>&1 connects stderr to where stdout is going at that moment.
Then stdout is redirected later. The order matters.
```

This is one of the most important thinking lessons in the chapter.

---

# Part F: `/dev/null`

## Feynman analogy

`/dev/null` is the trash can.

Anything written there disappears.

Run:

```bash
ls input missing-directory 2> /dev/null
```

Question:

```text
What disappeared?
What still appeared?
```

Now:

```bash
ls input missing-directory > /dev/null
```

Question:

```text
What disappeared this time?
What still appeared?
```

Finally:

```bash
ls input missing-directory > /dev/null 2>&1
```

Question:

```text
What appeared on the terminal?
```

Expected answer:

```text
Nothing. Both stdout and stderr were discarded.
```

---

## Disciplined-thinking checkpoint

Before using `/dev/null`, answer:

```text
Am I hiding noise, or am I hiding evidence?
```

Do not use `/dev/null` to avoid understanding an error.

---

## Explain to a ten-year-old

Explain:

```bash
ls input missing-directory > output/combined.txt 2>&1
```

Use:

```text
Normal output goes...
Error output goes...
The order matters because...
```

---

## Session 3 self-test

Without notes, explain:

```bash
command > out.txt
command 2> err.txt
command > out.txt 2> err.txt
command > both.txt 2>&1
command 2>&1 > out.txt
command > /dev/null 2>&1
```

For each one, identify:

```text
stdout:
stderr:
risk:
verification:
```
