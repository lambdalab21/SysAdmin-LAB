# The Linux Command Line, Chapter 6: Redirection

Use these guides after reading or while reading Chapter 6 of William Shotts, *The Linux Command Line*.

A cleaner phrasing: “Create Markdown file(s) for Shotts Chapter 6, ‘Redirection.’ Use the Feynman method and force disciplined thinking rather than mindless typing.”

Main idea:

```text
A shell command is not just text on a screen.
It has streams.
Redirection changes where those streams go.
```

Core disciplined-thinking rule:

```text
Before pressing Enter, identify:
1. What command will run?
2. What is stdin?
3. Where will stdout go?
4. Where will stderr go?
5. Will a file be created, overwritten, or appended?
6. How will I verify the result?
```

One-time setup:

```bash
mkdir -p ~/tlcl-ch06-redirection/{input,output,errors,lab,tmp}
cd ~/tlcl-ch06-redirection

cat > input/fruits.txt <<'EOF'
apple
banana
orange
banana
apple
grape
EOF

cat > input/names.txt <<'EOF'
alice
bob
charlie
diana
EOF

cat > input/app.log <<'EOF'
INFO started
ERROR failed login alice
INFO request /index.html
WARN disk almost full
ERROR timeout db01
INFO stopped
EOF
```

Verify setup:

```bash
find ~/tlcl-ch06-redirection -maxdepth 2 -type f -print
```

---
# Session 4: Pipes, Filters, and `tee`

## Read these Chapter 6 sections

Read the sections covering:

```text
pipes
filters
sort
uniq
wc
grep
head
tail
tee
```

The goal is not to type long pipelines. The goal is to build them carefully.

---

## Feynman analogy

A pipeline is an assembly line.

Each worker does one job:

```text
worker 1 selects lines
worker 2 sorts them
worker 3 counts duplicates
worker 4 counts final lines
```

A bad student writes a five-command pipeline at once.

A disciplined student builds one stage at a time.

---

# Pipeline rule

Use this pattern:

```text
Stage 1: run and inspect
Stage 2: add one command and inspect
Stage 3: add one command and inspect
Final: explain what question the pipeline answers
```

---

# Drill 1: Sort and unique

Run one stage at a time:

```bash
cd ~/tlcl-ch06-redirection
cat input/fruits.txt
```

Then:

```bash
cat input/fruits.txt | sort
```

Then:

```bash
cat input/fruits.txt | sort | uniq
```

Then:

```bash
cat input/fruits.txt | sort | uniq -c
```

Question:

```text
What question does the final pipeline answer?
```

Expected idea:

```text
It counts how many times each fruit appears, after sorting makes duplicates adjacent.
```

---

# Drill 2: Avoid unnecessary `cat`, but understand why

Compare:

```bash
cat input/fruits.txt | sort | uniq -c
sort input/fruits.txt | uniq -c
```

Explain:

```text
The second is usually cleaner because sort can read the file directly.
The first can still be useful for learning pipelines because it makes the stream visible.
```

Do not turn “useless cat” into a religion. The point is understanding data flow.

---

# Drill 3: Filter logs with `grep`

Build slowly:

```bash
cat input/app.log
```

```bash
grep ERROR input/app.log
```

```bash
grep ERROR input/app.log | wc -l
```

Question:

```text
What question does the final command answer?
```

Expected answer:

```text
How many ERROR lines are in the log?
```

---

# Drill 4: Use `head` and `tail` to inspect, not guess

Run:

```bash
cat input/app.log | head
cat input/app.log | tail
```

For larger command output:

```bash
ls -l /usr/bin | head
ls -l /usr/bin | tail
ls -l /usr/bin | wc -l
```

Explain:

```text
head and tail help inspect large output safely.
```

---

# Drill 5: `tee` saves and shows output

## Feynman analogy

`tee` is a T-shaped pipe.

One copy continues to the screen or next command.
One copy goes into a file.

Run:

```bash
grep ERROR input/app.log | tee output/error-lines.txt
cat output/error-lines.txt
```

Now:

```bash
grep ERROR input/app.log | tee output/error-lines.txt | wc -l
```

Question:

```text
What did tee save?
What did wc count?
```

Expected idea:

```text
tee saved the ERROR lines.
wc counted the ERROR lines that passed through the pipeline.
```

---

# Drill 6: Append with `tee -a`

Run:

```bash
echo 'First run' | tee output/tee-log.txt
echo 'Second run' | tee -a output/tee-log.txt
cat output/tee-log.txt
```

Explain:

```text
tee overwrites by default.
tee -a appends.
```

---

# Disciplined pipeline worksheet

For any pipeline, fill out:

```text
Question I am answering:
Stage 1 command:
Stage 1 output means:
Stage 2 command:
Stage 2 output means:
Stage 3 command:
Final answer:
Possible false assumption:
```

---

## Session 4 self-test

Explain these:

```bash
sort input/fruits.txt | uniq -c
sort input/fruits.txt | uniq | wc -l
grep ERROR input/app.log | wc -l
grep ERROR input/app.log | tee output/errors.txt | wc -l
ls -l /usr/bin | head
```

For each one, answer:

```text
What does each stage receive?
What does each stage output?
What question does the full pipeline answer?
```
