# The Linux Command Line, Chapter 6: Redirection

Use these guides after reading or while reading Chapter 6 of William Shotts, *The Linux Command Line*.

A cleaner phrasing: “Create Markdown file(s) for Shotts Chapter 6, ‘Redirection.’ Use the Feynman method and force disciplined thinking rather than mindless typing.”

Main idea:

```text
A shell command is not just text on a screen.
It has streams.
Redirection changes where those streams go.
```

Core disciplined-thinking rule:

```text
Before pressing Enter, identify:
1. What command will run?
2. What is stdin?
3. Where will stdout go?
4. Where will stderr go?
5. Will a file be created, overwritten, or appended?
6. How will I verify the result?
```

One-time setup:

```bash
mkdir -p ~/tlcl-ch06-redirection/{input,output,errors,lab,tmp}
cd ~/tlcl-ch06-redirection

cat > input/fruits.txt <<'EOF'
apple
banana
orange
banana
apple
grape
EOF

cat > input/names.txt <<'EOF'
alice
bob
charlie
diana
EOF

cat > input/app.log <<'EOF'
INFO started
ERROR failed login alice
INFO request /index.html
WARN disk almost full
ERROR timeout db01
INFO stopped
EOF
```

Verify setup:

```bash
find ~/tlcl-ch06-redirection -maxdepth 2 -type f -print
```

---
# Session 1: Streams and File Descriptors

## Read these Chapter 6 sections

Read the opening of Chapter 6 where Shotts introduces:

```text
standard input
standard output
standard error
redirection
```

Do not worry about memorizing every symbol yet. First understand the streams.

---

## Feynman analogy

Imagine a command is a small machine.

It can have:

```text
an input chute
an output chute
an error chute
```

In shell terms:

```text
stdin  = input chute
stdout = normal output chute
stderr = error-message chute
```

The terminal normally provides input and displays both normal output and error output.

Redirection is plumbing.

You are changing where the chutes go.

---

## Before touching the keyboard

Answer in writing:

1. What is standard input?
2. What is standard output?
3. What is standard error?
4. Why are error messages kept separate from normal output?
5. What does it mean to redirect a stream?

---

## File descriptors

Remember these numbers:

```text
0 = stdin
1 = stdout
2 = stderr
```

Say aloud:

```text
Zero is input.
One is normal output.
Two is error output.
```

---

## Drill 1: Normal output

Predict first:

```text
Will this print normal output or an error?
```

Run:

```bash
cd ~/tlcl-ch06-redirection
ls input
```

Explain:

```text
The command succeeded, so the listing went to stdout.
stdout normally appears on the terminal.
```

---

## Drill 2: Error output

Predict first:

```text
Does this directory exist?
If not, which stream should receive the message?
```

Run:

```bash
ls missing-directory
```

Explain:

```text
The command failed.
The error message went to stderr.
Stderr normally appears on the terminal too.
```

---

## Drill 3: Both stdout and stderr can appear on screen

Run:

```bash
ls input missing-directory
```

Questions:

1. Which part was normal output?
2. Which part was error output?
3. Why did both appear on the terminal?

Expected idea:

```text
Both stdout and stderr normally display on the terminal unless redirected.
```

---

## Explain to a ten-year-old

Explain this command:

```bash
ls input missing-directory
```

Use:

```text
The command looked for two things.
For the thing that existed, it sent...
For the thing that did not exist, it sent...
Both appeared on the screen because...
```

---

## Discipline checkpoint

Before moving on, explain:

```text
stdout and stderr may look similar on the terminal,
but the shell can redirect them separately.
```

---

## Mini self-test

Identify stdout and stderr:

```bash
echo hello
cat input/fruits.txt
cat missing.txt
ls input missing-directory
```

For each command, write:

```text
stdout:
stderr:
why:
```
