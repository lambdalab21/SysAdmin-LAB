# TLCL Chapter 6 — Redirection: Disciplined Study Plan

Recommended split:

| Session | File | Focus |
|---|---|---|
| 1 | `01_streams_and_file_descriptors.md` | stdin, stdout, stderr, file descriptors 0/1/2 |
| 2 | `02_stdout_stdin_overwrite_append.md` | `>`, `>>`, `<`, file creation and overwrite risk |
| 3 | `03_stderr_and_combining_streams.md` | `2>`, `2>>`, `2>&1`, redirection order, `/dev/null` |
| 4 | `04_pipes_and_tee.md` | `|`, filters, `tee`, build pipelines one stage at a time |
| 5 | `05_applied_lab_and_self_test.md` | practical redirection lab and retention test |

Chapter 6 should not be taught as punctuation memorization.

Teach it as stream control:

```text
stdin  = where input comes from
stdout = where normal output goes
stderr = where error messages go
```

The student should learn this pattern:

```text
predict stream behavior
→ run command
→ inspect files and terminal output
→ explain why it happened
→ change one thing and test again
```

End standard:

```text
He can explain where stdin, stdout, and stderr go before running the command.
He knows when a command overwrites versus appends.
He understands that redirection order matters.
He builds pipelines one stage at a time.
```
