# The Linux Command Line, Chapter 6: Redirection

Use these guides after reading or while reading Chapter 6 of William Shotts, *The Linux Command Line*.

A cleaner phrasing: “Create Markdown file(s) for Shotts Chapter 6, ‘Redirection.’ Use the Feynman method and force disciplined thinking rather than mindless typing.”

Main idea:

```text
A shell command is not just text on a screen.
It has streams.
Redirection changes where those streams go.
```

Core disciplined-thinking rule:

```text
Before pressing Enter, identify:
1. What command will run?
2. What is stdin?
3. Where will stdout go?
4. Where will stderr go?
5. Will a file be created, overwritten, or appended?
6. How will I verify the result?
```

One-time setup:

```bash
mkdir -p ~/tlcl-ch06-redirection/{input,output,errors,lab,tmp}
cd ~/tlcl-ch06-redirection

cat > input/fruits.txt <<'EOF'
apple
banana
orange
banana
apple
grape
EOF

cat > input/names.txt <<'EOF'
alice
bob
charlie
diana
EOF

cat > input/app.log <<'EOF'
INFO started
ERROR failed login alice
INFO request /index.html
WARN disk almost full
ERROR timeout db01
INFO stopped
EOF
```

Verify setup:

```bash
find ~/tlcl-ch06-redirection -maxdepth 2 -type f -print
```

---
# Session 2: Redirecting stdout and stdin

## Read these Chapter 6 sections

Read the sections that cover:

```text
>
>>
<
cat
sort
uniq
wc
```

Focus on the meaning of redirection, not just the symbols.

---

## Feynman analogy

The terminal is like a screen.

`>` is like saying:

```text
Do not show the normal output on the screen.
Put it into this file instead.
```

`>>` is like saying:

```text
Add the normal output to the end of this file.
Do not erase what is already there.
```

`<` is like saying:

```text
Take input from this file instead of from my keyboard.
```

---

# Part A: Redirect stdout with `>`

## Before running

Answer:

```text
Will this create a file?
Will it overwrite an existing file?
Will output appear on the terminal?
```

Run:

```bash
cd ~/tlcl-ch06-redirection
ls input > output/input-list.txt
```

Inspect:

```bash
cat output/input-list.txt
ls -l output/input-list.txt
```

Explain:

```text
stdout from ls went into output/input-list.txt.
The listing did not appear on the terminal because stdout was redirected.
```

---

# Part B: Overwrite danger

Create a file:

```bash
echo 'first line' > output/overwrite-test.txt
cat output/overwrite-test.txt
```

Predict:

```text
What will happen to 'first line' after the next command?
```

Run:

```bash
echo 'second line' > output/overwrite-test.txt
cat output/overwrite-test.txt
```

Explain:

```text
> overwrote the file.
The original content is gone.
```

Discipline rule:

```text
Before using >, ask: Am I willing to replace this file?
```

---

# Part C: Append with `>>`

Run:

```bash
echo 'first line' > output/append-test.txt
echo 'second line' >> output/append-test.txt
echo 'third line' >> output/append-test.txt
cat output/append-test.txt
```

Explain:

```text
> created or replaced the file.
>> added new lines to the end.
```

Question:

```text
Which is safer when collecting log-like output over time: > or >>?
```

Expected idea:

```text
>> is safer if you want to keep earlier content.
```

---

# Part D: Redirect stdin with `<`

Run:

```bash
sort < input/fruits.txt
```

Compare:

```bash
sort input/fruits.txt
```

Question:

```text
Did both commands sort the same data?
What changed about where sort received input?
```

Explain:

```text
With <, the shell connected the file to stdin.
Without <, sort opened the file named as an argument.
The output still went to stdout.
```

---

# Part E: Use output redirection with sorted data

Predict:

```text
Where will sorted output go?
Will the terminal show the sorted list?
```

Run:

```bash
sort input/fruits.txt > output/fruits-sorted.txt
cat output/fruits-sorted.txt
```

Now append a count:

```bash
wc -l input/fruits.txt >> output/fruits-sorted.txt
cat output/fruits-sorted.txt
```

Question:

```text
Was appending the count to the sorted list a good report format?
```

Expected idea:

```text
It works technically, but a better report would include a label.
```

---

## Explain to a ten-year-old

Explain:

```bash
sort input/fruits.txt > output/fruits-sorted.txt
```

Use:

```text
sort reads...
The normal output would usually go...
The > symbol sends it...
Then I can check it by...
```

---

## Session 2 self-test

Without notes, answer:

1. What does `>` do?
2. What does `>>` do?
3. What does `<` do?
4. What is the danger of `>`?
5. How do you verify what went into a redirected file?

Write commands for:

```text
Save ls output to a file.
Append date output to a file.
Sort fruits.txt and save the result.
Count lines and append the count to a report.
```
