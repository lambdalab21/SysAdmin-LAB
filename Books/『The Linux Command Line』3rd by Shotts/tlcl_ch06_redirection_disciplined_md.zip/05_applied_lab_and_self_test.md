# The Linux Command Line, Chapter 6: Redirection

Use these guides after reading or while reading Chapter 6 of William Shotts, *The Linux Command Line*.

A cleaner phrasing: “Create Markdown file(s) for Shotts Chapter 6, ‘Redirection.’ Use the Feynman method and force disciplined thinking rather than mindless typing.”

Main idea:

```text
A shell command is not just text on a screen.
It has streams.
Redirection changes where those streams go.
```

Core disciplined-thinking rule:

```text
Before pressing Enter, identify:
1. What command will run?
2. What is stdin?
3. Where will stdout go?
4. Where will stderr go?
5. Will a file be created, overwritten, or appended?
6. How will I verify the result?
```

One-time setup:

```bash
mkdir -p ~/tlcl-ch06-redirection/{input,output,errors,lab,tmp}
cd ~/tlcl-ch06-redirection

cat > input/fruits.txt <<'EOF'
apple
banana
orange
banana
apple
grape
EOF

cat > input/names.txt <<'EOF'
alice
bob
charlie
diana
EOF

cat > input/app.log <<'EOF'
INFO started
ERROR failed login alice
INFO request /index.html
WARN disk almost full
ERROR timeout db01
INFO stopped
EOF
```

Verify setup:

```bash
find ~/tlcl-ch06-redirection -maxdepth 2 -type f -print
```

---
# Session 5: Applied Lab and Self-Test

## Purpose

This session forces practical use of Chapter 6.

No mindless typing. Every command must answer a question.

Use this worksheet before each task:

```text
Question:
Command:
stdin:
stdout:
stderr:
File created/changed:
Verification command:
Explanation:
```

---

# Lab 1: Create a small report

Goal:

```text
Create a report containing:
- current date
- current hostname
- number of files in input/
- number of ERROR lines in app.log
```

Build it step by step.

```bash
cd ~/tlcl-ch06-redirection

date > output/system-report.txt
hostname >> output/system-report.txt
find input -type f | wc -l >> output/system-report.txt
grep ERROR input/app.log | wc -l >> output/system-report.txt
cat output/system-report.txt
```

Question:

```text
Is the report readable enough?
```

Improve it:

```bash
{
  echo 'System report'
  echo '============='
  printf 'Date: '
  date
  printf 'Hostname: '
  hostname
  printf 'Input files: '
  find input -type f | wc -l
  printf 'ERROR lines: '
  grep ERROR input/app.log | wc -l
} > output/system-report-labeled.txt

cat output/system-report-labeled.txt
```

Explain:

```text
The braces group multiple commands.
The final > redirects the combined stdout of the group.
```

---

# Lab 2: Capture normal output and errors separately

Goal:

```text
Run one command that succeeds partly and fails partly.
Save normal output and error output separately.
```

Run:

```bash
ls input missing-directory > output/lab2-normal.txt 2> errors/lab2-errors.txt
```

Verify:

```bash
cat output/lab2-normal.txt
cat errors/lab2-errors.txt
```

Explain:

```text
stdout went to...
stderr went to...
This helps troubleshooting because...
```

---

# Lab 3: Build a pipeline from a log question

Question:

```text
How many unique log levels appear in app.log?
```

Build slowly:

```bash
cat input/app.log
cut -d ' ' -f1 input/app.log
cut -d ' ' -f1 input/app.log | sort
cut -d ' ' -f1 input/app.log | sort | uniq
cut -d ' ' -f1 input/app.log | sort | uniq | wc -l
```

Explain:

```text
cut selected the first field.
sort grouped equal values.
uniq removed duplicates.
wc -l counted unique levels.
```

---

# Lab 4: Save intermediate output with `tee`

Question:

```text
Which lines are warnings or errors, and how many are there?
```

Run:

```bash
grep -E 'ERROR|WARN' input/app.log | tee output/warn-error-lines.txt | wc -l
cat output/warn-error-lines.txt
```

Explain:

```text
grep selected warning/error lines.
tee saved the selected lines.
wc counted the selected lines.
```

---

# Lab 5: Redirection order challenge

Predict before running.

Command A:

```bash
ls input missing-directory > output/a.txt 2>&1
```

Command B:

```bash
ls input missing-directory 2>&1 > output/b.txt
```

Run both:

```bash
ls input missing-directory > output/a.txt 2>&1
ls input missing-directory 2>&1 > output/b.txt
```

Inspect:

```bash
cat output/a.txt
cat output/b.txt
```

Explain:

```text
Command A captured both stdout and stderr.
Command B redirected stderr to the old stdout first, then redirected stdout to the file.
Order matters.
```

---

# Final self-test

Without notes, write commands for each task.

1. Save `ls input` output to `output/input-list.txt`.
2. Append `date` output to `output/input-list.txt`.
3. Sort `input/fruits.txt` and save it.
4. Save errors from `ls missing` to `errors/missing.txt`.
5. Save stdout and stderr separately from `ls input missing`.
6. Save stdout and stderr together from `ls input missing`.
7. Discard only errors from `ls input missing`.
8. Count unique fruits.
9. Count ERROR lines in `input/app.log`.
10. Save ERROR lines with `tee` while also counting them.

Expected command patterns:

```bash
ls input > output/input-list.txt
date >> output/input-list.txt
sort input/fruits.txt > output/fruits-sorted.txt
ls missing 2> errors/missing.txt
ls input missing > output/normal.txt 2> errors/error.txt
ls input missing > output/both.txt 2>&1
ls input missing 2> /dev/null
sort input/fruits.txt | uniq -c
grep ERROR input/app.log | wc -l
grep ERROR input/app.log | tee output/errors.txt | wc -l
```

---

# Final explain-back

Explain these symbols in plain English:

```text
>
>>
<
|
2>
2>>
2>&1
/dev/null
tee
```

Use the form:

```text
This changes where ______ goes.
It is useful when ______.
The danger is ______.
I verify it by ______.
```

---

# End standard

He understands Shotts Chapter 6 only if he can say:

```text
I know the difference between stdin, stdout, and stderr.
I know when I am overwriting or appending.
I know how to capture errors separately.
I know that redirection order matters.
I build pipelines one stage at a time.
I explain the data flow before typing the command.
```
